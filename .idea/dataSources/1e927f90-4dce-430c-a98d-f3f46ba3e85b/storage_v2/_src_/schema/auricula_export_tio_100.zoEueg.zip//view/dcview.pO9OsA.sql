create view dcview as
select `op`.`OID`              AS `OID`,
       `op`.`CPID`             AS `CPID`,
       `op`.`MEDICINETYPE`     AS `MEDICINETYPE`,
       `cp`.`CENTREID`         AS `CENTREID`,
       `op`.`STARTDATE`        AS `STARTDATE`,
       `op`.`ENDDATE`          AS `ENDDATE`,
       `dc`.`STATUS`           AS `STATUS`,
       `p`.`SSN`               AS `SSN`,
       `rp`.`LASTNAME`         AS `LASTNAME`,
       `rp`.`FIRSTNAME`        AS `FIRSTNAME`,
       `dc`.`PLANED_DATE`      AS `DCPLANEDDATE`,
       `dc`.`CALLEDDATE`       AS `DCCALLEDDATE`,
       `op`.`DCTHERAPYDROPOUT` AS `DCTHERAPYDROPOUT`,
       `dc`.`DCID`             AS `DCID`,
       `dc`.`TSCREATED`        AS `DCTSCREATED`,
       `dc`.`RESULT`           AS `DCRESULT`,
       `dc`.`STATUS`           AS `DCSTATUS`,
       `dc`.`DATE`             AS `DCDATE`,
       `dc`.`ABORTED`          AS `DCABORTED`,
       `op`.`ACTIVE`           AS `ACTIVE`
from (((((`auricula_export_tio_100`.`ordinationperiod` `op` left join `auricula_export_tio_100`.`dcconversion` `dc` on ((`op`.`OID` = `dc`.`OID`))) join `auricula_export_tio_100`.`centrepatient` `cp` on ((`op`.`CPID` = `cp`.`CPID`))) join `auricula_export_tio_100`.`regionpatient` `rp` on ((`rp`.`RPID` = `cp`.`RPID`))) join `auricula_export_tio_100`.`patient` `p` on ((`rp`.`PID` = `p`.`PID`)))
         join `auricula_export_tio_100`.`ordpatient` `o` on ((`rp`.`RPID` = `o`.`RPID`)))
where (`op`.`DCCONVERSION` = 2);

