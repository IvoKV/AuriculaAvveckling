create view opendletterview as
select `ordp`.`OID`                   AS `OID`,
       `cp`.`CENTREID`                AS `CENTREID`,
       `ordp`.`ATRIAL_FIB`            AS `ATRIAL_FIB`,
       `ordp`.`VALVE_MALFUNCTION`     AS `VALVE_MALFUNCTION`,
       `ordp`.`VENOUS_TROMB`          AS `VENOUS_TROMB`,
       `ordp`.`OTHER`                 AS `OTHER`,
       `ordp`.`OTHERCHILDINDICATION`  AS `OTHERCHILDINDICATION`,
       `ordp`.`DCCONVERSION`          AS `DCCONVERSION`,
       `ordp`.`PERIOD_LENGTH`         AS `PERIOD_LENGTH`,
       `ordp`.`LENGTHCOMMENT`         AS `LENGTHCOMMENT`,
       `ordp`.`MEDICIN`               AS `MEDICIN`,
       `ordp`.`STARTDATE`             AS `STARTDATE`,
       `ordp`.`ENDDATE`               AS `ENDDATE`,
       `ordp`.`REASON_STOPPED`        AS `REASON_STOPPED`,
       `p`.`SSN`                      AS `SSN`,
       `rp`.`LASTNAME`                AS `PLASTNAME`,
       `rp`.`FIRSTNAME`               AS `PFIRSTNAME`,
       `rp`.`DATEOFBIRTH`             AS `DATEOFBIRTH`,
       `rp`.`ADDRESS`                 AS `PATADDRESS`,
       `rp`.`ZIPCODE`                 AS `PATZIPCODE`,
       `rp`.`CITY`                    AS `PATCITY`,
       `rp`.`SEX`                     AS `SEX`,
       `op`.`OTHER_ADDRESS`           AS `OTHER_ADDRESS`,
       `op`.`OTHER_CITY`              AS `OTHER_CITY`,
       `op`.`OTHER_ZIPCODE`           AS `OTHER_ZIPCODE`,
       `op`.`LETTER_TO_OTHER_ADDRESS` AS `LETTER_TO_OTHER_ADDRESS`,
       `op`.`DATE_FROM_OTHER_ADDRESS` AS `DATE_FROM_OTHER_ADDRESS`,
       `op`.`DATE_TO_OTHER_ADDRESS`   AS `DATE_TO_OTHER_ADDRESS`,
       `cp`.`FAXLETTER`               AS `FAXLETTER`,
       `cp`.`PAL`                     AS `PAL`,
       `cp`.`SSK`                     AS `SSK`,
       `cp`.`PAL_TEXT`                AS `PAL_TEXT`,
       `cp`.`FAXNO_SSK`               AS `FAXNO_SSK`,
       `c`.`COM_REL_TYPE`             AS `COM_REL_TYPE`,
       `c`.`COM_REL_ID`               AS `COM_REL_ID`,
       `c`.`FILENAME`                 AS `FILENAME`,
       `c`.`MESSAGE`                  AS `MESSAGE`,
       `c`.`RESPONSIBLE`              AS `RESPONSIBLE`,
       `c`.`TSCREATED`                AS `COMMTSCREATED`,
       `u`.`FIRSTNAME`                AS `USERFIRSTNAME`,
       `u`.`LASTNAME`                 AS `USERLASTNAME`,
       `u`.`TITLE`                    AS `TITLE`,
       `u`.`EMAIL`                    AS `USEREMAIL`,
       `pe`.`FIRSTNAME`               AS `PEOPLEFIRSTNAME`,
       `pe`.`LASTNAME`                AS `PEOPLELASTNAME`
from ((((((((`auricula_export_tio_100`.`ordinationperiod` `ordp` join `auricula_export_tio_100`.`communication` `c` on ((
        ((`c`.`COM_REL_TYPE` = 7) or (`c`.`COM_REL_TYPE` = 20)) and
        (`c`.`COM_REL_ID` = `ordp`.`OID`)))) join `auricula_export_tio_100`.`centrepatient` `cp` on ((`c`.`CPID` = `cp`.`CPID`))) join `auricula_export_tio_100`.`regionpatient` `rp` on ((`rp`.`RPID` = `cp`.`RPID`))) join `auricula_export_tio_100`.`patient` `p` on ((`p`.`PID` = `rp`.`PID`))) join `auricula_export_tio_100`.`ordpatient` `op` on ((`op`.`RPID` = `rp`.`RPID`))) join `auricula_export_tio_100`.`centre` `ce` on ((`ce`.`ID` = `cp`.`CENTREID`))) join `auricula_export_tio_100`.`user` `u` on ((
        ((`c`.`RESPONSIBLE` = 'System') and (`ordp`.`UPDATEDBY` = `u`.`ID`)) or
        ((`c`.`RESPONSIBLE` is not null) and (`c`.`RESPONSIBLE` = `u`.`ID`)) or
        ((`c`.`RESPONSIBLE` is null) and (`ordp`.`UPDATEDBY` = `u`.`ID`)))))
         left join `auricula_export_tio_100`.`people` `pe` on ((`pe`.`PEOPLEID` = `cp`.`PAL`)));

