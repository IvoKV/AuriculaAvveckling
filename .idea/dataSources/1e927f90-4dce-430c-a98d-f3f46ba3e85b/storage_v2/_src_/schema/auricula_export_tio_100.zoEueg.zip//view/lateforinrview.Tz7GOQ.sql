create view lateforinrview as
select `auricula_export_tio_100`.`centrepatient`.`CENTREID` AS `CENTREID`,
       `ordp`.`CPID`                                        AS `cpid`,
       `ordp`.`OID`                                         AS `oid`,
       `ordp`.`ACTIVE`                                      AS `active`,
       `ordp`.`INRMETHOD`                                   AS `inrmethod`,
       `ordp`.`ENDDATE`                                     AS `enddate`,
       `ordp`.`REASON_STOPPED`                              AS `reason_stopped`,
       max(`w`.`ORDINATIONDATE`)                            AS `MAX_ORD_DAT`,
       max(`w`.`DATE_NEXT_VISIT`)                           AS `MAX_NEXT_VISIT`,
       `ca`.`ATTRIBUTEVALUE`                                AS `attributevalue`
from ((((`auricula_export_tio_100`.`centrepatient` join `auricula_export_tio_100`.`ordinationperiod` `ordp` on ((`auricula_export_tio_100`.`centrepatient`.`CPID` = `ordp`.`CPID`))) join `auricula_export_tio_100`.`centreattribute` `ca` on ((
        (`auricula_export_tio_100`.`centrepatient`.`CENTREID` = `ca`.`ID`) and
        (`ca`.`ATTRIBUTENAME` = 'LETTER_MODE')))) join `auricula_export_tio_100`.`inr` `i` on ((`ordp`.`OID` = `i`.`OID`)))
         join `auricula_export_tio_100`.`waranordination` `w` on ((`i`.`INRID` = `w`.`INRID`)))
where (((`ordp`.`MEDICINETYPE` is null) or (`ordp`.`MEDICINETYPE` = 1)) and exists(select 1 AS `Not_used`
                                                                                   from ((`auricula_export_tio_100`.`inr` `inr2` join `auricula_export_tio_100`.`waranordination` `w2` on ((`inr2`.`INRID` = `w2`.`INRID`)))
                                                                                            join `auricula_export_tio_100`.`ordinationperiod` `ordp2`
                                                                                                 on ((`inr2`.`OID` = `ordp2`.`OID`)))
                                                                                   where ((`auricula_export_tio_100`.`centrepatient`.`CPID` = `ordp2`.`CPID`) and
                                                                                          (`ordp2`.`ACTIVE` = 1) and
                                                                                          (`ordp`.`ACTIVE` = 0))) is false)
group by `auricula_export_tio_100`.`centrepatient`.`CENTREID`, `ordp`.`OID`, `ordp`.`ACTIVE`, `ordp`.`INRMETHOD`,
         `ordp`.`ENDDATE`, `ordp`.`REASON_STOPPED`, `ca`.`ATTRIBUTEVALUE`;

