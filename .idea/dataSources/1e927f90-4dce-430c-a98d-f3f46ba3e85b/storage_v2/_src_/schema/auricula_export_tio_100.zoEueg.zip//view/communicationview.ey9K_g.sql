create view communicationview as
select `auricula_export_tio_100`.`communication`.`COM_REL_TYPE` AS `COM_REL_TYPE`,
       `auricula_export_tio_100`.`communication`.`COM_REL_ID`   AS `COM_REL_ID`,
       `auricula_export_tio_100`.`communication`.`CPID`         AS `CPID`,
       `auricula_export_tio_100`.`communication`.`DISTRIBUTION` AS `DISTRIBUTION`,
       `auricula_export_tio_100`.`communication`.`FILENAME`     AS `FILENAME`,
       `auricula_export_tio_100`.`communication`.`MESSAGE`      AS `MESSAGE`,
       `auricula_export_tio_100`.`communication`.`RESPONSIBLE`  AS `RESPONSIBLE`,
       `auricula_export_tio_100`.`communication`.`STATUS`       AS `STATUS`,
       `auricula_export_tio_100`.`communication`.`CREATEDBY`    AS `CREATEDBY`,
       `auricula_export_tio_100`.`communication`.`UPDATEDBY`    AS `UPDATEDBY`,
       `auricula_export_tio_100`.`communication`.`TSCREATED`    AS `TSCREATED`,
       `auricula_export_tio_100`.`communication`.`TSUPDATED`    AS `TSUPDATED`,
       `cp`.`CENTREID`                                          AS `CENTREID`,
       `p`.`SSN`                                                AS `SSN`,
       `rp`.`LASTNAME`                                          AS `LASTNAME`,
       `rp`.`FIRSTNAME`                                         AS `FIRSTNAME`,
       `rp`.`ADDRESS`                                           AS `ADDRESS`,
       `rp`.`ZIPCODE`                                           AS `ZIPCODE`,
       `rp`.`CITY`                                              AS `CITY`
from (((`auricula_export_tio_100`.`communication` join `auricula_export_tio_100`.`centrepatient` `cp` on ((`auricula_export_tio_100`.`communication`.`CPID` = `cp`.`CPID`))) join `auricula_export_tio_100`.`regionpatient` `rp` on ((`cp`.`RPID` = `rp`.`RPID`)))
         join `auricula_export_tio_100`.`patient` `p` on ((`p`.`PID` = `rp`.`PID`)));

