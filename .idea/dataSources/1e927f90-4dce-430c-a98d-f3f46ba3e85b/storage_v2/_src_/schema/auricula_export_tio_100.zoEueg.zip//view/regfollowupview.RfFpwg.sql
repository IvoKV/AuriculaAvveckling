create view regfollowupview as
select `auricula_export_tio_100`.`mce`.`MCEID`              AS `MCEID`,
       `auricula_export_tio_100`.`mce`.`CPID`               AS `CPID`,
       `auricula_export_tio_100`.`patient`.`SSN`            AS `SSN`,
       `r`.`CONTACT_DATE`                                   AS `CONTACT_DATE`,
       `auricula_export_tio_100`.`mce`.`STATUS`             AS `STATUS`,
       `auricula_export_tio_100`.`centrepatient`.`CENTREID` AS `CENTREID`
from ((((`auricula_export_tio_100`.`registration` `r` join `auricula_export_tio_100`.`mce` on ((`auricula_export_tio_100`.`mce`.`MCEID` = `r`.`MCEID`))) join `auricula_export_tio_100`.`centrepatient` on ((
        `auricula_export_tio_100`.`mce`.`CPID` =
        `auricula_export_tio_100`.`centrepatient`.`CPID`))) join `auricula_export_tio_100`.`regionpatient` on ((
        `auricula_export_tio_100`.`centrepatient`.`RPID` = `auricula_export_tio_100`.`regionpatient`.`RPID`)))
         join `auricula_export_tio_100`.`patient`
              on ((`auricula_export_tio_100`.`regionpatient`.`PID` = `auricula_export_tio_100`.`patient`.`PID`)))
where ((`auricula_export_tio_100`.`regionpatient`.`DECEASED` is null) and
       (`auricula_export_tio_100`.`regionpatient`.`DATEOFDEATH` is null));

