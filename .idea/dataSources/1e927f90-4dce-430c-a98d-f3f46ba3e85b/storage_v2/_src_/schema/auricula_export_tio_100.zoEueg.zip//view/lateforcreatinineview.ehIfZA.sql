create view lateforcreatinineview as
select `auricula_export_tio_100`.`ordinationperiod`.`OID`  AS `OID`,
       `auricula_export_tio_100`.`ordinationperiod`.`CPID` AS `CPID`,
       `auricula_export_tio_100`.`creatinin`.`ID`          AS `CID`
from (`auricula_export_tio_100`.`creatinin`
         join `auricula_export_tio_100`.`ordinationperiod`
              on ((`auricula_export_tio_100`.`creatinin`.`OID` = `auricula_export_tio_100`.`ordinationperiod`.`OID`)))
where ((`auricula_export_tio_100`.`ordinationperiod`.`ACTIVE` = 1) and
       (`auricula_export_tio_100`.`creatinin`.`TESTDATE` is null) and
       ((`auricula_export_tio_100`.`creatinin`.`PLANEDDATE` + interval '7' day) < curdate()) and
       (`auricula_export_tio_100`.`ordinationperiod`.`MEDICINETYPE` = 2) and
       (`auricula_export_tio_100`.`creatinin`.`STATUS` <> 1));

