create view autolettercommcprppat as
select `cp`.`CPID`               AS `CPID`,
       `auto`.`TSSENT`           AS `TSSENT`,
       `auto`.`FILENAME`         AS `FILENAME`,
       `pat`.`SSN`               AS `SSN`,
       `pat`.`PID`               AS `PID`,
       `regpat`.`FIRSTNAME`      AS `FIRSTNAME`,
       `regpat`.`LASTNAME`       AS `LASTNAME`,
       `regpat`.`ADDRESS`        AS `ADDRESS`,
       `regpat`.`CITY`           AS `CITY`,
       concat(convert(date_format(`auto`.`TSSENT`, '%Y/%m/%d') using utf8mb3), '/', `cp`.`CENTREID`, '/',
              `auto`.`FILENAME`) AS `PATH`
from ((((`auricula_export_tio_100`.`centrepatient` `cp` join `auricula_export_tio_100`.`communication` `comm` on ((`cp`.`CPID` = `comm`.`CPID`))) join `auricula_export_tio_100`.`autosentletters` `auto` on ((
        (`comm`.`COM_REL_ID` = `auto`.`COM_REL_ID`) and
        (`comm`.`COM_REL_TYPE` = `auto`.`COM_REL_TYPE`)))) join `auricula_export_tio_100`.`regionpatient` `regpat` on ((`cp`.`RPID` = `regpat`.`RPID`)))
         join `auricula_export_tio_100`.`patient` `pat` on ((`regpat`.`PID` = `pat`.`PID`)));

