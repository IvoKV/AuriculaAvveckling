create view deleteview as
select `auricula_export_tio_100`.`regionpatient`.`PID`      AS `PID`,
       `auricula_export_tio_100`.`centrepatient`.`CPID`     AS `CPID`,
       `auricula_export_tio_100`.`centrepatient`.`CENTREID` AS `CENTREID`,
       'MCE'                                                AS `REGTYPE`,
       `auricula_export_tio_100`.`mce`.`MCEID`              AS `REGID`
from ((`auricula_export_tio_100`.`mce` join `auricula_export_tio_100`.`centrepatient` on ((
        `auricula_export_tio_100`.`mce`.`CPID` = `auricula_export_tio_100`.`centrepatient`.`CPID`)))
         join `auricula_export_tio_100`.`regionpatient`
              on ((`auricula_export_tio_100`.`regionpatient`.`RPID` = `auricula_export_tio_100`.`centrepatient`.`RPID`)))
union
select `auricula_export_tio_100`.`regionpatient`.`PID`      AS `PID`,
       `auricula_export_tio_100`.`centrepatient`.`CPID`     AS `CPID`,
       `auricula_export_tio_100`.`centrepatient`.`CENTREID` AS `CENTREID`,
       'OP'                                                 AS `REGTYPE`,
       `auricula_export_tio_100`.`ordinationperiod`.`OID`   AS `REGID`
from ((`auricula_export_tio_100`.`ordinationperiod` join `auricula_export_tio_100`.`centrepatient` on ((
        `auricula_export_tio_100`.`ordinationperiod`.`CPID` = `auricula_export_tio_100`.`centrepatient`.`CPID`)))
         join `auricula_export_tio_100`.`regionpatient` on ((`auricula_export_tio_100`.`regionpatient`.`RPID` =
                                                             `auricula_export_tio_100`.`centrepatient`.`RPID`)));

